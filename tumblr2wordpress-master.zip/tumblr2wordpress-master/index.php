<?php

define('T2W_VERSION', '0.4');

# Some pieces of content will have to be parsed into HTML where we have to add
# HTML strucutre (e.g. around conversations)
require_once("markdown.php");

# Check for valid input
$username = isset($_REQUEST['username']) && !empty($_REQUEST['username']) ? $_REQUEST['username'] : '';

if(empty($username)): ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Tumblr2WordPress: Export Your Tumblr Blog To WordPress RSS</title>
    <link rel="profile" href="http://microformats.org/profile/hcard">
    <link rel="stylesheet" href="t2w.css" type="text/css">
  </head>
  <body>
    <h1>Tumblr2WordPress: Export Your Tumblr to WordPress</h1>

    <p>This tool will create a WordPress compatible XML file from your
        Tumblr blog, which you can then save and import into WordPress.</p>

    <dl class="about">
      <dt>Version</dt>
      <dd><?php echo T2W_VERSION ?></dd>
      <dt>Author</dt>
      <dd>Originally by
          <a class="h-card" href="http://haochen.me/">Hao Chen</a>
      </dd>
      <dd>This version by
          <a class="h-card" href="http://benward.me">Ben Ward</a>
      </dd>
      <dt>License</dt>
      <dd><a rel="license" href="http://www.gnu.org/licenses/gpl.html">GPL v3</a></dd>
      <dt>Source Code</dt>
      <dd><a href="http://github.com/benward/tumblr2wordpress">
          github.com/benward/tumblr2wordpress</a></dd>
    </dl>

    <div class="yahoo">
      <h2>Welcome, fear-stricken Tumblr friend!</h2>
      <p>Good morning! By now you'll have
        <a href="http://www.guardian.co.uk/technology/2013/may/19/yahoo-poised-buy-tumblr">heard the news</a>—or be frantically responding
        to the rumour thereof—that Tumblr is selling to Yahoo for a gigantic pot
        of money. Congratulations to them, you may think, followed by a spinal chill
        of panic as your mind harks back to the bloodied fates of previous Yahoo acquisitions:
        Geocities, Upcoming, Delicious…</p>
      <p>Firstly, don't panic. No matter what anyone is saying on the internet,
        it's very unlikely that anything will change suddenly; that's not how
        these things work. Plus, Yahoo's intentions will be for Tumblr to be a
        success, and it's under new management, so you never know, it might work
        out. Still, regardless of what happens to the services we love in the future,
        it is <em>always</em> smart to have back-ups, so hopefully this tool
        can help you, whether you want to jump ship for WordPress, or just have
        some piece of mind.</p>
      <p>There are a few things that you should note:</p>
      <ul>
        <li>This tool is <em>old</em>. It was written a few years ago when I intended
          to merge my Tumblr into a WordPress install. I never did it, and the tool
          is a little incomplete as a result. It's still here, though.</li>
        <li>The tool was written before Tumblr had support for multiple image
          uploads, so if you do a lot of that you might not get the full export
          you're hoping for.</li>
        <li>The tool was also written before WordPress introduced their own concept
          of top-level post types: Photos, Quotes, Video posts, etc. All posts from
          this tool will be appropriately categorised, but maybe not quite as
          cleverly as newer WordPress tools. You might want to consider the
          <a href="http://wordpress.org/plugins/tumblr-importer/">Tumblr Importer</a>
          plugin for WordPress instead.</li>
        <li>The tool will give you some highly pedantic and slightly opinionated
          HTML5 output. Which is all good. And it will attempt to coerce Audio
          into an HTML5 audio player too. The actual file may or may not work in
          this form, depending on the original source.</li>
        <li>Posts with images will still reference the images on Tumblr's servers.
          If you want to copy the images to your server as well you'll either need
          to run another script, or install a WordPress plugin such as
          Milan Dinicć's <a href="http://blog.milandinic.com/wordpress/plugins/cache-images/">Cache
          Images</a> plugin.</li>
      </ul>
      <p>All that being said, you might still find the tool useful, and I hope you do.
        The code was originally written by <a class="h-card" href="http://haochen.me/">Hao Chen</a>,
        and was substantially updated by me, <a class="h-card" href="http://benward.me">Ben Ward</a>.
      </p>

      <p>The source code (which, I cannot stress enough, is very old now) is
        <a href="http://github.com/benward/tumblr2wordpress">on Github</a>,
        if you'd like to run your own copy or make changes.</p>
    </div>


    <form method="POST" action="">

    <fieldset>
        <legend>Tumblr Account</legend>
        <label for="tumblr-user">Tumblr Blog URL (Your username; not your email address or custom domain):</label>
        <input type="text" id="tumblr-user" name="username" size="40" placeholder="username">
        <samp>.tumblr.com</samp>
    </fieldset>
    <fieldset>
        <legend>Exported Content Format</legend>
        <p>By default, Tumblr posts are output are converted into HTML,
            just as they would be on your Tumblr blog page.</p>
        <ul>
            <li><input type="radio" name="filter" id="fltr-html" value="html" checked>
                <label for="fltr-html">HTML</label>
            </li>
            <li><input type="radio" name="filter" id="fltr-text" value="text">
                <label for="fltr-text">Plain Text</label>
            </li>
            <li><input type="radio" name="filter" id="fltr-none" value="none">
                <label for="fltr-none">Raw Input (preserving Markdown)</label>
            </li>
        </ul>
    </fieldset>
    <fieldset>
        <legend>Permalink Slugs</legend>
        <p>Here, choose the permalink format for the posts when they
            are imported into WordPress.</p>
        <p>A reliable permalink may allow you to redirect content between
           your old and new site. <a href="#help-permalinks">Read more</a>.</p>
        <ul>
            <li><input type="radio" name="permaform" id="link-id" value="id" checked>
                <label for="link-id">Use the Tumblr post ID.
                    e.g. <kbd>http://blog.example.com/posts/<strong>12345678</strong></kbd>
                </label>
            </li>
            <li><input type="radio" name="permaform" id="link-combo" value="combo">
                <label for="link-combo">Create a combined slug
                    e.g. <kbd>http://blog.example.com/posts/<strong>12345678-my-blog-post-title</strong></kbd>
                </label>
            </li>
            <li><input type="radio" name="permaform" id="link-orig" value="text">
                <label for="link-orig">Use original Tumblr text slug only.
                    e.g. <kbd>http://blog.example.com/posts/<strong>my-blog-post-title-about-stuff</strong></kbd>
                </label>
            </li>
        </ul>
    </fieldset>
    <fieldset>
        <legend>Export for</legend>
        <ul>
            <li><input type="radio" name="type" id="xp-dotcom" value="wordpress.com" checked>
                <label for="xp-dotcom">WordPress.com Hosted Blog</label>
            </li>
            <li>
                <input type="radio" name="type" id="xp-dotorg" value="wordpress">
                <label for="xp-dotorg">Self-Hosted WordPress Installation</label>
            </li>
        </ul>
      </fieldset>
    <fieldset>
        <legend>Post Options</legend>
            <div>
        <label for="publish-state">Imported Post Status</label>
        <select name="publish-state" id="publish-state">
            <option value="publish" selected>Published</option>
            <option value="draft">Draft</option>
        </select>
        </div>

        <div>
        <label for="comment-state">Comments</label>
        <select name="comment-state" id="comment-state">
            <option value="off" selected>Comments Disabled</option>
            <option value="on">Comments Enabled</option>
        </select>
        </div>

        <div>
        <label for="ping-state">Pings</label>
        <select name="ping-state" id="ping-state">
            <option value="off" selected>Pingbacks Disabled</option>
            <option value="on">Pingbacks Enabled</option>
        </select>
        </div>
      </fieldset>
      <fieldset>
        <legend>Ready?</legend>
        <input type="submit" value="Export">
        <p>After a short pause, your browser will download an XML file
            containing your Tumblr posts, converted for use in WordPress.
            You should open this file in a text editor to see the
            instructions on how to import your posts, and also check for
            any warnings the exporter has generated for your posts. For
            example, you may need to re-upload audio and image files from
            your posts.</p>
    </fieldset>
    </form>
    <h2>Notes and Help</h2>
    <div id="help-permalinks">
        <p>So, you're migrating your blog. Good for you!
            If you're running your tumblr blog on your own domain
            (<samp>yourdomain.com</samp> rather than <samp>me.tumblr.com</samp>,
            for example), then you can set up redirects from the old URLs that
            people are still linking to, to the imported post on your new
            WordPress blog.</p>
        <p>Basically, where you have a Tumblr post URL that looks like this:
          <samp>http://example.com/post/12345678/this-is-a-post</samp>,
          the only part that matters is
          <samp>http://example.com/post/12345678/</samp>. That number is
          the ID. Everything after that gets ignored when Tumblr loads
          the post.</p>
          <p>When you export your post, you're encouraged to include that
          post ID in the new permalink slugs, since that way you can redirect
          from one to the other.</p>
          <p>If you take your current Tumblr custom domain, and host it
          yourself, you can set up a simple <samp>.htaccess</samp> redirect
          for people linking to your old posts:</p>
          <pre><code>RewriteEngine On
RewriteRule ^/?posts/([0-9]+).*$ http://wordpress.example.com/blog/$1</code></pre>
        </div>
    </p>
  </body>
</html>
<?php
  # If we output the form, end now:
  exit();
endif;

  # Didn't output the form. So, process the input:

$type = $_REQUEST["type"];
$i = 0;

$posts = array();
$feed = '';
$allTags = array();
$warnings = array();
$markdown = false;

# Tumblr Query Options:
switch($_REQUEST["filter"]) {
    case "text":
        # Plaintext Content
        $filter = "&filter=text";
        break;
    case "none":
        # Do not post-process posts (leaves Markdown intact)
        $filter = "&filter=none";
        $markdown = true;
        break;
    default:
        $filter = "";
        break;
}

# Output Options

# Permalink Format
switch($_REQUEST["permaform"]) {
    case "combo":
        # ID and Hyphenated Title
        $permalink_format = "combined";
        break;
    case "text":
        # Title
        $permalink_format = "text";
        break;
    case "id":
    default:
        # Id only
        $permalink_format = "id";
        break;
}

# Publication Status
switch($_REQUEST["publish-state"]) {
    case "draft":
        $publish = 'draft';
        break;
    case "publish":
    default:
        $publish = 'publish';
        break;
}

# Enable Comments
if('on' === $_REQUEST["comment-state"]) {
    $comments = 'open';
}
else {
    $comments = 'closed';
}

# Enable Pingback
if('on' === $_REQUEST["ping-state"]) {
    $pings = 'open';
}
else {
    $pings = 'closed';
}

# OK. Query the Tumblr API for the posts and get them all in 50-post batches:
try {
    do {
      $url = 'http://'.$username.'.tumblr.com/api/read?start='. $i . '&num=50' . $filter;

      if(function_exists("curl_init")) {

          $ch = curl_init();
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_USERAGENT, TL_USERAGENT);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); # Follow 301/302
            curl_setopt($ch, CURLOPT_POST, 0);
            curl_setopt($ch, CURLOPT_URL, $url);
            $data = curl_exec($ch);
            $curl_info = curl_getinfo($ch);

            if(200 != $curl_info['http_code']) {
                # Some kind of error. Just debug output for now:
                header("500", true, 500);
                echo "<title>Tumblr2WordPress Error</title>\n";
                echo "<h1>Tumblr API Request Failed</h1>\n";
                echo "<p>Requesting a set of posts from the Tumblr API failed.
                See below for debugging output.</p>\n";
                echo "<dl>\n";
                echo "\t<dt>Error was</dt>\n\t<dd><code>" . $status_code . "</code></dd>\n";
                echo "\t<dt>Request URL</dt>\n\t<dd><code>" . $url . "</code></dd>\n";
                echo "\t<dt>Posts fetched (so far)</dt>\n\t<dd><code>" . $i . "</code></dd>\n";
                echo "\t<dt>Last API response</dt>\n\t<dd><pre><code>" . htmlspecialchars($data) . "</code></pre></dd>\n";
                echo "\t<dt>Curl Info</dt>\n\t<dd><pre><code>";
                print_r($curl_info);
                echo "</code></pre></dd>\n";
                echo "</dl>";
                die();
            }

            curl_close($ch);
      }
      else {

          $data = file_get_contents($url);

      }

      $feed = new SimpleXMLElement($data);
      $posts = array_merge($posts, $feed->xpath('posts//post'));
      $i = (int)$feed->posts->attributes()->start + 50;
    } while($i <= (int)$feed->posts["total"]);
}
catch(Exception $e) {
    header("500", true, 500);
    echo "<title>Tumblr2WordPress Error</title>\n";
    echo "<h1>Error fetching Tumblr posts</h1>\n";
    echo "<p>Something went wrong whilst collecting posts from the Tumblr API,
    see below for debugging output.</p>\n";
    echo "<dl>\n";
    echo "\t<dt>Error was</dt>\n\t<dd><code>" . $e->getMessage() . "</code></dd>\n";
    echo "\t<dt>Request URL</dt>\n\t<dd><code>" . $url . "</code></dd>\n";
    echo "\t<dt>Posts fetched (so far)</dt>\n\t<dd><code>" . $i . "</code></dd>\n";
    echo "\t<dt>Last API response</dt>\n\t<dd><pre><code>" . htmlspecialchars($data) . "</code></pre></dd>\n";
    echo "</dl>";
    die();
}
function formatForWP($str)
{
  global $type;
  switch($type)
  {
    case "wordpress.com":
      $str = formatVideoForWP(formatImageForWP($str));
  }
  return $str;
}
function formatImageForWP($str)
{
  if(preg_match_all('/(<p>)?\s*(<img[^>]*\/?>)\s*(<\/p>)?/', $str, $matches))
  {
    for($i=0;$i<sizeof($matches[0]);$i++)
    {
      $str = str_replace($matches[0][$i], str_replace('/>',' alt=""/>', $matches[2][$i]), $str);
    }
  }
  return $str;
}

function formatVideoForWP($str)
{
  if(preg_match_all('/<object[\s\S]*src="([\S\s]*?)&amp;[\s\S]*"[\s\S]*<\/object>/', $str, $matches))
  {
    for($i=0;$i<sizeof($matches);$i++)
    {
      if((strpos($matches[1][$i], 'youtube.com') !== false))
      {
        $str = str_replace($matches[0][$i], '[youtube='.$matches[1][$i].']', $str);
      }
    }
  }
  return $str;
}

function removeWeirdChars($str)
{
  return trim(preg_replace('{(-)\1+}','$1',preg_replace('/[^a-zA-Z0-9-]/', '', str_replace(' ','-',strtolower(strip_tags($str))))),'-');
}

function getTags($post)
{
  if($post->attributes()->type)
  {
    echo "<category><![CDATA[" . $post->attributes()->type . "]]></category>\n";
    echo "\t\t<category domain=\"category\" nicename=\"" . $post->attributes()->type . "\"><![CDATA[" . $post->attributes()->type . "]]></category>\n";
  }
  else
  {
    echo "<category><![CDATA[Uncategorized]]></category>\n";
    echo "\t\t<category domain=\"category\" nicename=\"uncategorized\"><![CDATA[Uncategorized]]></category>\n";
  }
  if($post->tag)
  {
    foreach($post->tag as $tag)
    {
      echo "\t\t<category domain=\"tag\"><![CDATA[$tag]]></category>\n";
      echo "\t\t<category domain=\"tag\" nicename=\"" . removeWeirdChars($tag) . "\"><![CDATA[$tag]]></category>\n";
      addTag((String)$tag);
    }
  }
}

function addTag($tag)
{
  global $allTags;
  if(!in_array($tag, $allTags))
    $allTags[] = $tag;
}

function getAllTags()
{
  global $allTags;
  foreach($allTags as $tag)
  {
    echo "\t<wp:tag><wp:tag_slug>". removeWeirdChars($tag) . "</wp:tag_slug><wp:tag_name><![CDATA[$tag]]></wp:tag_name></wp:tag>\n";
  }
}

function formatPermalinkSlug($id, $text) {
  global $permalink_format;
    switch($permalink_format) {
        case 'combo':
            return $id . '-' . removeWeirdChars($text);
        case 'text':
            return removeWeirdChars($text);
        case 'id':
        default:
            return $id;
    }
}

# Try to extract a sane, single line blog title from input text, and
# (optionally) remove it from the entry body to avoid duplication.
function formatEntryTitle(&$text, $strip=true) {
    $lines = explode("\n", $text);
    $block_count = 0; # How far into the entry are we?
    for($i=0; $l = $lines[$i]; $i++) {

        if(empty($l)) {
            # Ignoring emptry lines
            continue;
        }
        elseif(preg_match('/^\s*(#+|<[hH][1-6]>).*$/', $l, $match)) {
            # Matches a heading in Markdown or HTML

            # Now we need to see if the title embeds any links. If it does,
            # we want to strip out the link mark-up…

            # If raw input:
            if($markdown) {
                # Run markdown:
                $l = Markdown($l);
            }
            # Crudely check for <a>
            $contains_link = !(false === stripos('<a', $l));

            if( true === $strip
                && false === $contains_link) {
                # If there has been no other content so far (allowing one block
                # for quote attribution), and we're stripping titles out of the
                # text to avoid duplication, do it:
                array_splice($lines, $i, 1);
                $text = implode("\n", $lines);
            }

            # In the final return, strip not-inline HTML tags.
            return str_replace('\n', '', strip_tags($l));
            #'<abbr><acronym><i><b><strong><em><code><kbd><samp><span><q>
            # <cite><dfn><ins><del><mark><meter><rp><rt><ruby><sub><sup>
            # <time><var>'
        }
        else {
            $block_count++;
        }

        if($block_count > 2) {
            # Too far into the post. Give up.
            break;
        }
    }
    return '';
}

# Use curl follow-location to resolve 30* redirects to the canonical URL:
# Use this to find whether media is hosted on the Tumblr server or at a
# public location.
function resolveRedirects($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, TL_USERAGENT);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_exec($ch);
    $rsp = curl_getinfo($ch);
    curl_close($ch);
    return $rsp['url'];
}

# Check if a media URL is hosted on Tumblr's server and record
# a warning if so.
function checkMediaForWarnings($media_url, $post, $type) {
  global $warnings;

  $resolved_url = resolveRedirects($media_url);

  if(false !== stripos($resolved_url, 'tumblr.com')) {
      # Audio file is hosted on Tumblr, and won't be accessible.
        $warnings[] = array(
            'url' => $post,
            'error' => "Post references a $type file hosted on
 Tumblr.com. This file will not be accessible
 from a post hosted on your own site. You need to host
 `{$media_url}`
 elsewhere and update the post."
        );
  }
}

function getWarnings() {
  global $warnings;
    if(!empty($warnings)):
    ?>
<!-- Warnings: -->
<!-- The following warnings were recorded when exporting your Tumblr posts, -->
<!-- and may require attention and manual intervention to full restore  -->
<!-- your posts. -->

    <?php
        foreach($warnings as $id=>$data) {
            echo <<<WARNING
<!-- Warning for: {$data['url']} -->
<!-- {$data['error']} -->

WARNING;
        }
    endif;
}

header('content-type: text/xml');
header("content-disposition: attachment; filename=tumblr_$username.xml");
?>
<?php echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n"; ?>
<!-- This is a WordPress eXtended RSS file generated from your Tumblr posts. -->
<!-- It contains information about your blog's posts, comments, and categories. -->
<!-- You may use this file to transfer that content from one site to another. -->
<!-- This file is not intended to serve as a complete backup of your blog. -->

<!-- To import this information into a WordPress blog follow these steps. -->
<!-- 1. Log into that blog as an administrator. -->
<!-- 2. Go to Manage: Import in the blog's admin panels. -->
<!-- 3. Choose "WordPress" from the list. -->
<!-- 4. Upload this file using the form provided on that page. -->
<!-- 5. You will first be asked to map the authors in this export file to users -->
<!--    on the blog.  For each author, you may choose to map to an -->
<!--    existing user on the blog or to create a new user -->
<!-- 6. WordPress will then import each of the posts, comments, and categories -->
<!--    contained in this file into your blog -->

<!-- generator="Tumblr2WordPress/<?php echo T2W_VERSION ?>" created="<?php echo date("Y-m-d H:i") ?>"-->
<rss version="2.0"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:wfw="http://wellformedweb.org/CommentAPI/"
  xmlns:dc="http://purl.org/dc/elements/1.1/"
  xmlns:wp="http://wordpress.org/export/1.0/"
>
<channel>
  <title><?php echo htmlspecialchars($feed->tumblelog->attributes()->title) ?></title>
  <link>http://<?php echo $feed->tumblelog->attributes()->name ?>.tumblr.com/</link>
  <description><?php echo htmlspecialchars($feed->tumblelog) ?></description>
  <pubDate><?php echo date("r") ?></pubDate>
  <generator>http://<?php echo 'Tumblr2WordPress/' . T2W_VERSION . '(' . $_SERVER['HTTP_HOST'] . ')' ?></generator>
  <language>en</language>
  <wp:wxr_version>1.0</wp:wxr_version>
  <wp:base_site_url>http://<?php echo $feed->tumblelog->attributes()->name ?>.tumblr.com/</wp:base_site_url>
  <wp:base_blog_url>http://<?php echo $feed->tumblelog->attributes()->name ?>.tumblr.com/</wp:base_blog_url>
  <wp:category>
    <wp:category_nicename>uncategorized</wp:category_nicename>
    <wp:category_parent></wp:category_parent>
    <wp:cat_name><![CDATA[Uncategorized]]></wp:cat_name>
  </wp:category>

<?php
    ob_start();
  foreach($posts as $post)
  {
?>
  <item>
<?php
        // Shared Output:
?>
    <link><?php echo $post->attributes()->url ?></link>
    <pubDate><?php echo $post->attributes()->date ?> +0000</pubDate>
    <dc:creator><![CDATA[post_author]]></dc:creator>
    <?php getTags($post) ?>
    <guid isPermaLink="false"><?php echo $post->attributes()->url ?></guid>
    <!--<wp:post_id><?php echo $post->attributes()->id ?></wp:post_id>-->
    <wp:post_date><?php echo date('Y-m-d G:i:s', (double)$post->attributes()->{'unix-timestamp'}) ?></wp:post_date>
    <wp:post_date_gmt><?php echo str_replace(" GMT", "", $post->attributes()->{'date-gmt'}) ?></wp:post_date_gmt>
    <wp:comment_status><?php echo $comments ?></wp:comment_status>
    <wp:ping_status><?php echo $pings ?></wp:ping_status>
    <wp:status><?php echo $publish ?></wp:status>
    <wp:post_parent>0</wp:post_parent>
    <wp:menu_order>0</wp:menu_order>
    <wp:post_type>post</wp:post_type>
    <wp:post_password></wp:post_password>
<?php
        // Post Specific Elements:
    switch($post->attributes()->type)
    {
      case "regular": ?>
    <title><?php echo htmlspecialchars($post->{'regular-title'}) ?></title>
    <description></description>
    <content:encoded><![CDATA[<?php echo formatForWP($post->{'regular-body'}) ?>]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, $post->{'regular-title'}) ?></wp:post_name>
<?php   break;


      case "photo":
      $post_content = $post->{'photo-caption'};
      $image = "";

      # Handle photosets vs. single photos
      # Using combined HTML5 + classes shim:
      if(isset($post->photoset)) {
          foreach($post->xpath('photoset//photo') as $photo) {
              $image .= "\n<div class=\"figure\"><figure>\n";
              $image .= "  <img src=\"{$photo->{'photo-url'}}\" alt=\"\">\n";
                if(!empty($photo->attributes()->caption)) {
                    $image .= "  <p class=\"figcaption\"><figcaption>{$photo->attributes()->caption}</figcaption></p>\n";
                }
                $image .= "</figure></div>\n";
          }
      }
      else {
          $image = <<<FIGURE
<div class="figure"><figure>
  <img src="{$post->{'photo-url'}}" alt="">
</figure></div>\n\n
FIGURE;
            }
      ?>
    <title><?php echo htmlspecialchars(formatEntryTitle(&$post_content)) ?></title>
    <description></description>
    <content:encoded><![CDATA[<?php echo $image; ?>
    <?php echo formatForWP($post_content) ?>]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, $post->{'photo-caption'}) ?></wp:post_name>
<?php
      break;

      case "quote":
      $post_content = $post->{'quote-source'};

      # Mark-up the quote:
            if($markdown) {
                # Add Markdown quotes, and hard line-breaks
                $quote_text = "> " . str_replace("\n", "  \n> ", $post->{'quote-text'}) . "\n";
            }
            else {
                $quote_text = "<blockquote>" . $post->{'quote-text'} . "</blockquote>";
            }
    ?>
    <title><?php echo htmlspecialchars(formatEntryTitle(&$post_content)) ?></title>
    <description></description>
    <content:encoded><![CDATA[<?php echo $quote_text ?>

    <?php echo formatForWP($post_content) ?>]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, str_replace('&#8220;','',str_replace('&#8221;','',$post->{'quote-text'}))) ?></wp:post_name>
<?php
      break;

      case "link": ?>
    <title><?php echo htmlspecialchars(strip_tags($post->{'link-text'})) ?></title>
    <description><?php echo htmlspecialchars(strip_tags($post->{'link-description'})) ?></description>
    <content:encoded><![CDATA[Link: <a href="<?php echo $post->{'link-url'} ?>"><?php echo $post->{'link-text'} ?></a>

    <?php echo formatForWP($post->{'link-description'}) ?>]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, $post->{'link-text'}) ?></wp:post_name>
<?php
      break;

        case "conversation": ?>
    <title><?php echo htmlspecialchars(strip_tags($post->{'conversation-title'})) ?></title>
    <description></description>
    <content:encoded><![CDATA[<?php
        foreach($post->{'conversation-line'} as $line) {
            ?><cite><?php
                echo ($markdown) ? preg_replace('/(<\/?p>|\n)/', '', Markdown($line->attributes()->label)) : $line->attributes()->label
            ?></cite> <q><?php
                echo ($markdown) ? preg_replace('/(<\/?p>|\n)/', '', Markdown($line)) : $line;
            ?></q><br>
        <?php } ?>]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, $post->{'conservation-title'}) ?></wp:post_name>
<?php
      break;

      case "video":
      $post_content = $post->{'video-caption'};
    ?>
    <title><?php echo htmlspecialchars(formatEntryTitle(&$post_content)) ?></title>
    <description></description>
    <content:encoded><![CDATA[
        <?php if($type == 'wordpress.com' && strpos($post->{'video-source'}, 'youtube.com') !== false) { ?>
    [youtube=<?php echo $post->{'video-source'} ?>]
        <?php } elseif($type == 'wordpress.com' && strpos($post->{'video-source'}, 'video.google.com') !== false) { ?>
    [googlevideo=<?php preg_match('/src="([\S\s]*?)"/', $post->{'video-player'}, $matches); echo $matches[1]; ?>]
        <?php } else { ?>
      <?php echo $post->{'video-player'} ?>
        <?php } ?>
      <?php echo $post_content ?>
      ]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, $post->{'video-caption'}) ?></wp:post_name>
<?php
      break;

      case "audio":
      $post_content = $post->{'audio-caption'};
      $audio_file = preg_match('/audio_file=([\S\s]*?)(&|")/', $post->{'audio-player'}, $matches);
            checkMediaForWarnings($matches[1], $post->attributes()->url, "audio");
    ?>
    <title><?php echo htmlspecialchars(formatEntryTitle(&$post_content)) ?></title>
    <description></description>
    <content:encoded><![CDATA[<audio controls src="<?php echo $matches[1] ?>"><a href="<?php echo $matches[1]; ?>">Audio</a></audio>

    <?php echo $post_content ?>]]></content:encoded>
    <wp:post_name><?php echo formatPermalinkSlug($post->attributes()->id, $post->{'audio-caption'}) ?></wp:post_name>
<?php
      break;
    }
?>
  </item>
<?php
  }
  $out = ob_get_contents();
  ob_end_clean();
  getWarnings();
  getAllTags();
  echo $out;
?>
</channel>
</rss>